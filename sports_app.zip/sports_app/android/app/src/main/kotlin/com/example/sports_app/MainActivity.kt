package com.example.sports_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
