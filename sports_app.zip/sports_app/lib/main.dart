import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sports_app/providers/match_provider.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => MatchProvider()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({Key? key}) : super(key: key);

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;

  static final List<Widget> _widgetOptions = <Widget>[
    const MatchDetailsScreen(),
    const TeamProfilesScreen(),
    const PlayerStatsScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  void initState() { 
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {  
      context.read<MatchProvider>().fetchLiveMatches(); // ✅ Fixed Provider access
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sports App'),
        backgroundColor: Colors.purpleAccent,
      ),
      body: _widgetOptions.elementAt(_selectedIndex),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(icon: Icon(Icons.sports_soccer), label: 'Match Details'),
          BottomNavigationBarItem(icon: Icon(Icons.group), label: 'Teams'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Players'),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.purpleAccent,
        onTap: _onItemTapped,
      ),
    );
  }
}

// Match Details Screen
class MatchDetailsScreen extends StatelessWidget {
  const MatchDetailsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text('Team A vs Team B', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          SizedBox(height: 10),
          Text('Score: 2 - 1', style: TextStyle(fontSize: 20)),
          Text('Time: 90+3 min', style: TextStyle(fontSize: 18)),
        ],
      ),
    );
  }
}

// Team Profiles Screen
class TeamProfilesScreen extends StatelessWidget {
  const TeamProfilesScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: const [
        ListTile(
          leading: Icon(Icons.sports_soccer),
          title: Text('Team A'),
          subtitle: Text('Farhan: Rahul'),
        ),
        ListTile(
          leading: Icon(Icons.sports_soccer),
          title: Text('Team B'),
          subtitle: Text('Rohit: Virat'),
        ),
      ],
    );
  }
}

// Player Stats Screen
class PlayerStatsScreen extends StatelessWidget {
  const PlayerStatsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: const [
        ListTile(
          leading: Icon(Icons.person),
          title: Text('Player 1'),
          subtitle: Text('Goals: 10 | Assists: 5'),
        ),
        ListTile(
          leading: Icon(Icons.person),
          title: Text('Player 2'),
          subtitle: Text('Goals: 7 | Assists: 8'),
        ),
      ],
    );
  }
}