import 'package:flutter/material.dart';

class MatchProvider with ChangeNotifier {
  void fetchLiveMatches() {
    // Your API call logic here
    print("Fetching live matches...");
    // After fetching data, notify listeners if needed
    notifyListeners();
  }
}